#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/mujib/lawnmower_ws/devel_isolated/ardumower:$CMAKE_PREFIX_PATH"
export PWD="/home/mujib/lawnmower_ws/build_isolated/ardumower"
export ROSLISP_PACKAGE_DIRECTORIES="/home/mujib/lawnmower_ws/devel_isolated/ardumower/share/common-lisp"
export ROS_PACKAGE_PATH="/home/mujib/lawnmower_ws/src/ardumower:$ROS_PACKAGE_PATH"