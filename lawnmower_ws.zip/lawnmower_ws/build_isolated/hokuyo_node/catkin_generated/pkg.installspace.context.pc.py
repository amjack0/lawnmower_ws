# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/mujib/lawnmower_ws/install_isolated/include".split(';') if "/home/mujib/lawnmower_ws/install_isolated/include" != "" else []
PROJECT_CATKIN_DEPENDS = "rosconsole".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-llibhokuyo".split(';') if "-llibhokuyo" != "" else []
PROJECT_NAME = "hokuyo_node"
PROJECT_SPACE_DIR = "/home/mujib/lawnmower_ws/install_isolated"
PROJECT_VERSION = "1.7.8"
