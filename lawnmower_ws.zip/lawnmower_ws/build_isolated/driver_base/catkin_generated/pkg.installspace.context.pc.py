# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/mujib/lawnmower_ws/install_isolated/include;/usr/include".split(';') if "/home/mujib/lawnmower_ws/install_isolated/include;/usr/include" != "" else []
PROJECT_CATKIN_DEPENDS = "message_runtime;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "driver_base"
PROJECT_SPACE_DIR = "/home/mujib/lawnmower_ws/install_isolated"
PROJECT_VERSION = "1.6.8"
